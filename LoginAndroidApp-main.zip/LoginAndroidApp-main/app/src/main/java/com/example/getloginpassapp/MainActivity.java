package com.example.getloginpassapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, GetDataAsyncTask.AsyncResponse {
    // Определение частных переменных-членов для представлений
    // EditText и представления Button, а также для логина, пароля и данных URL

    private EditText etLogin;
    private EditText etPassword;
    private Button buttonSubmit;
    private String login, password, url_link;
    // Этот метод вызывается при создании активности, он устанавливает представления и кнопки
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
// Поиск представлений EditText в XML-файле по идентификатору
        etLogin = findViewById(R.id.eTLogin);
        etPassword = findViewById(R.id.eTPassword);
        // Находим представление Button в XML-файле по ID и устанавливаем на него OnClickListener
        buttonSubmit = findViewById(R.id.buttonSubmit);
        buttonSubmit.setOnClickListener(this);
    }
    // Этот метод вызывается при нажатии на кнопку, он извлекает данные логина и пароля и запускает асинхронную задачу GetDataAsyncTask для получения полного имени
    @Override
    public void onClick(View view) {
        login = etLogin.getText().toString();
        password = etPassword.getText().toString();
        url_link = "http://shamill8.beget.tech/Rex.php";
        // Запуск асинхронной задачи GetDataAsyncTask с текущим контекстом в качестве аргумента, которым является эта MainActivity
        new GetDataAsyncTask(this).execute(login, password, url_link);

        /*Intent intent = new Intent(this, ViewActivity.class);
        intent.putExtra("login", etLogin.getText().toString());
        intent.putExtra("password", etPassword.getText().toString());
        startActivity(intent);*/
    }
    // Этот метод вызывается, когда завершается асинхронная задача GetDataAsyncTask, он создает намерение для запуска ViewActivity с полными данными имени в качестве дополнительного параметра
        @Override
    public void processFinish(String output) {
        Intent intent = new Intent(this, ViewActivity.class);
        intent.putExtra("full_name", output);
        startActivity(intent);
    }
}